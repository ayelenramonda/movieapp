class Prestamo {
    constructor(nombre, taza, cuotas, limite, tipodeprestamo) {
      this.nombre = nombre;
      this.taza = taza;
      this.cuotas = cuotas;
      this.limite = limite;
      this.tipodeprestamo = tipodeprestamo;
    }
}

let form = document.querySelector("#prestamoNuevo")
let todosPrestamos = document.querySelector("#todosPrestamos")

let prestamos = []

form.addEventListener("submit", (event) => {
    event.preventDefault()
    let nombre = document.querySelector("#nya").value
    let taza = document.querySelector("#taza").value
    let cuota = document.querySelector("#cuota").value
    let limite = document.querySelector("#limite").value
    let tipodeprestamo = document.querySelector("#tipo").value
    prestamos.push(new Prestamo(nombre, taza, cuota, limite, tipodeprestamo))
    localStorage.setItem("prestamos", JSON.stringify(prestamos))
    //console.log(prestamos)
    form.reset()
    mostrarI()
   
})

const mostrarI = () => {
  todosPrestamos.innerHTML = ''
  prestamos = JSON.parse(localStorage.getItem('prestamos'))
  if(prestamos === null){
    prestamos = []
  }else{
    prestamos.forEach(prestamos => {
      todosPrestamos.innerHTML = todosPrestamos.innerHTML +=`   
      <div class="card border-secondary mb-4" style="max-width: 18rem; margin: 10px;">
      <div class="card-header" style="background-color: white;">Prestamo<b> ${prestamos.tipodeprestamo}</b></div>
      <div class="card-body">
        <p class="card-text">Nombre:<b> ${prestamos.nombre}</b></p>
        <p class="card-text">Taza: ${prestamos.taza}%</p>
        <p class="card-text">Cuotas: ${prestamos.cuotas}</p>
        <p class="card-text">Limite: ${prestamos.limite}</p>             

      </div>  
    
      </div>
      `
    });

  }
}

document.addEventListener("DOMContentLoaded", mostrarI)



