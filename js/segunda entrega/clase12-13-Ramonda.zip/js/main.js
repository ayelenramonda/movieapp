class Prestamo {
    constructor(nombre, taza, cuotas, limite, tipodeprestamo) {
      this.nombre = nombre;
      this.taza = taza;
      this.cuotas = cuotas;
      this.limite = limite;
      this.tipodeprestamo = tipodeprestamo;
    }
}

let form = document.querySelector("#prestamoNuevo")
let todosPrestamos = document.querySelector("#todosPrestamos")
let infoPrestamo = document.querySelector("#infoPrestamo")
let infoBorrar = document.querySelector("#infoBorrar")



let prestamos = []

form.addEventListener("submit", (event) => {
    event.preventDefault()
    let nombre = document.querySelector("#nya").value
    let taza = document.querySelector("#taza").value
    let cuota = document.querySelector("#cuota").value
    let limite = document.querySelector("#limite").value
    let tipodeprestamo = document.querySelector("#tipo").value
    prestamos.push(new Prestamo(nombre, taza, cuota, limite, tipodeprestamo))
    localStorage.setItem("prestamos", JSON.stringify(prestamos))
    form.reset()
    mostrarI()
   
})

const mostrarI = () => {
  todosPrestamos.innerHTML = ''
  prestamos = JSON.parse(localStorage.getItem('prestamos')) ?? []
  prestamos.forEach(prestamos => {
      let {nombre, taza: interes, cuotas, limite, tipodeprestamo} = prestamos
      todosPrestamos.innerHTML +=`   
      <div class="card border-secondary mb-4" style="max-width: 18rem; margin: 10px;">
      <div class="card-header" style="background-color: white;">Prestamo<b> ${tipodeprestamo} </b></div>
      <div class="card-body">
        <p class="card-text">Nombre:<b> ${nombre}</b></p>
        <p class="card-text">Taza: ${interes}%</p>
        <p class="card-text">Cuotas: ${cuotas}</p>
        <p class="card-text">Limite: ${limite}</p>             

      </div>  
    
      </div>
      `
    });

  };

  document.addEventListener("DOMContentLoaded", mostrarI)

  infoPrestamo.addEventListener('click', () => {
   
     Toastify({
         text: "Prestamo ingresado exitosamente",
         duration: 2000,
         //close: true,
         gravity: "top", // `top` or `bottom`
         position: "right", // `left`, `center` or `right`
        // stopOnFocus: true, // Prevents dismissing of toast on hover
         style: {
           background: "linear-gradient(to top, #33A2FF, #212468)",
         },
         onClick: function(){} // Callback after click
       }).showToast();
 })

 infoBorrar.addEventListener('click', () => {   
  Toastify({
    text: "Se borraron los datos",
    offset: {
      x: 50, // horizontal axis - can be a number or a string indicating unity. eg: '2em'
      y: 10 // vertical axis - can be a number or a string indicating unity. eg: '2em'
    },
    style: {
      background: "linear-gradient(to top, #731212, #C13737)",
    },
  }).showToast();
})


  
  
  



